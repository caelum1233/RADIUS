# RADIUS | SIXTHSENSE
*OBSCURITY IS OUR CODE.*

Autonomous Decentralized Peer-to-Peer Communication System for Android.

## Building the APK
1. Open this directory in **Android Studio Hedgehog / Iguana / Jellyfish (or newer)**.
2. Ensure JDK 17 is configured under File > Settings > Build, Execution, Deployment > Build Tools > Gradle.
3. Build the debug APK via terminal:
   ```bash
   ./gradlew assembleDebug
   ```
   The output APK will be generated at:
   `app/build/outputs/apk/debug/app-debug.apk`

4. Install to connected physical devices:
   ```bash
   adb install -r app/build/outputs/apk/debug/app-debug.apk
   ```

## Physical Device Testing Protocol
- Put physical devices in **Airplane Mode** (disable Cellular Data, Wi-Fi internet, SIM cards).
- Turn on **Bluetooth** and **Wi-Fi** (Wi-Fi Direct does not require an active router or internet connection).
- Launch RADIUS on both devices.
- Verify discovery on the **Nearby** screen.
- Press and hold the **Push-to-Talk (PTT)** circle on device 1 to transmit voice bursts directly to device 2.
- Place a peer-to-peer **Voice Call** to verify full-duplex offline audio.
- Test 3-device multi-hop mesh by positioning Device B between Device A and Device C.

RADIUS | SIXTHSENSE
