@rem RADIUS Gradle wrapper script for Windows
@gradle %*