# RADIUS ProGuard Rules
-keep class com.sixthsense.radius.data.local.entity.** { *; }
-dontwarn javax.annotation.**
-keepattributes *Annotation*