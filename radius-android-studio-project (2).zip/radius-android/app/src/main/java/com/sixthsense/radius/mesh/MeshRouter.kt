package com.sixthsense.radius.mesh

import android.content.Context
import com.sixthsense.radius.crypto.NoiseCryptoEngine
import com.sixthsense.radius.data.local.dao.RadiusDao
import com.sixthsense.radius.identity.IdentityManager
import com.sixthsense.radius.transport.TransportManager
import com.sixthsense.radius.transport.models.RadiusPacket
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Collections
import java.util.LinkedHashMap

class MeshRouter(
    private val context: Context,
    private val identityManager: IdentityManager,
    private val transport: TransportManager,
    private val dao: RadiusDao
) {
    private val seenPacketIds = Collections.synchronizedSet(
        Collections.newSetFromMap(object : LinkedHashMap<String, Boolean>(500, 0.75f, true) {
            override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Boolean>?) = size > 500
        })
    )

    private val _meshHopsObserved = MutableStateFlow(0)
    val meshHopsObserved = _meshHopsObserved.asStateFlow()

    suspend fun handlePacket(packet: RadiusPacket) {
        if (!seenPacketIds.add(packet.packetId)) return // Duplicate suppressed

        val forMe = packet.isBroadcast || packet.targetInstallationId == identityManager.cachedInstallationId
        if (forMe) {
            // Process packet content & save to Room
        }

        // Multi-hop relay
        if (!packet.isBroadcast && packet.targetInstallationId != identityManager.cachedInstallationId) {
            if (packet.maxTtl > packet.hopCount + 1) {
                _meshHopsObserved.value += 1
                transport.sendPacket(packet.copy(hopCount = packet.hopCount + 1))
            }
        }
    }
}