package com.sixthsense.radius.discovery

import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.wifi.p2p.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.net.InetAddress

class WifiDirectManager(private val context: Context, private val onConnected: (Boolean, InetAddress) -> Unit) {
    private val manager = context.getSystemService(Context.WIFI_P2P_SERVICE) as? WifiP2pManager
    private var channel: WifiP2pManager.Channel? = null
    val peers = MutableStateFlow<List<WifiP2pDevice>>(emptyList())

    @SuppressLint("MissingPermission")
    fun initialize() {
        channel = manager?.initialize(context, context.mainLooper, null)
        val filter = IntentFilter().apply {
            addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION)
            addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION)
        }
        context.registerReceiver(object : BroadcastReceiver() {
            override fun onReceive(c: Context?, intent: Intent?) {
                when (intent?.action) {
                    WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION -> {
                        channel?.let { ch -> manager?.requestPeers(ch) { peers.value = it?.deviceList?.toList() ?: emptyList() } }
                    }
                    WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION -> {
                        channel?.let { ch -> manager?.requestConnectionInfo(ch) { info ->
                            if (info?.groupFormed == true && info.groupOwnerAddress != null) {
                                onConnected(info.isGroupOwner, info.groupOwnerAddress)
                            }
                        }}
                    }
                }
            }
        }, filter)
    }

    @SuppressLint("MissingPermission")
    fun discoverPeers() {
        channel?.let { manager?.discoverPeers(it, null) }
    }
}