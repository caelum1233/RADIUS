package com.sixthsense.radius.data.local

import android.content.Context
import androidx.room.*
import com.sixthsense.radius.data.local.dao.RadiusDao
import com.sixthsense.radius.data.local.entity.MessageEntity
import com.sixthsense.radius.data.local.entity.PeerEntity

@Database(entities = [PeerEntity::class, MessageEntity::class], version = 1, exportSchema = false)
abstract class RadiusDatabase : RoomDatabase() {
    abstract fun radiusDao(): RadiusDao

    companion object {
        @Volatile private var INSTANCE: RadiusDatabase? = null
        fun getDatabase(context: Context): RadiusDatabase =
            INSTANCE ?: synchronized(this) {
                Room.databaseBuilder(context.applicationContext, RadiusDatabase::class.java, "radius_mesh.db")
                    .fallbackToDestructiveMigration()
                    .build().also { INSTANCE = it }
            }
    }
}