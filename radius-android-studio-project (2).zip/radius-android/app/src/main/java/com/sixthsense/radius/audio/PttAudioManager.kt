package com.sixthsense.radius.audio

import android.annotation.SuppressLint
import android.content.Context
import android.media.*
import com.sixthsense.radius.identity.IdentityManager
import com.sixthsense.radius.mesh.MeshRouter
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

class PttAudioManager(private val context: Context, private val meshRouter: MeshRouter, private val identityManager: IdentityManager) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var record: AudioRecord? = null
    private var track: AudioTrack? = null

    private val _pttState = MutableStateFlow(PttState.IDLE)
    val pttState = _pttState.asStateFlow()

    init {
        val minBuf = AudioTrack.getMinBufferSize(16000, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        track = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(16000).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(minBuf * 2)
            .build()
        track?.play()
    }

    @SuppressLint("MissingPermission")
    fun startTransmitting(channel: String = "general") {
        if (_pttState.value == PttState.TRANSMITTING) return
        _pttState.value = PttState.TRANSMITTING
        scope.launch {
            val bufSize = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            record = AudioRecord(MediaRecorder.AudioSource.VOICE_COMMUNICATION, 16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufSize)
            record?.startRecording()
            val chunk = ByteArray(640)
            while (isActive && _pttState.value == PttState.TRANSMITTING) {
                val read = record?.read(chunk, 0, chunk.size) ?: -1
                if (read > 0) {
                    // Send packet to mesh router
                }
            }
        }
    }

    fun stopTransmitting() {
        _pttState.value = PttState.IDLE
        record?.stop()
        record?.release()
        record = null
    }

    fun playIncomingAudio(pcmData: ByteArray) {
        track?.write(pcmData, 0, pcmData.size)
    }

    enum class PttState { IDLE, TRANSMITTING, RECEIVING }
}