package com.sixthsense.radius.discovery

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.bluetooth.le.*
import android.content.Context
import android.os.ParcelUuid
import com.sixthsense.radius.identity.IdentityManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.nio.charset.StandardCharsets
import java.util.UUID

class BleDiscoveryEngine(private val context: Context, private val identityManager: IdentityManager) {
    private val adapter: BluetoothAdapter? = (context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter
    private var advertiser: BluetoothLeAdvertiser? = null
    private var scanner: BluetoothLeScanner? = null

    private val _discoveredBlePeers = MutableStateFlow<Map<String, DiscoveredBleNode>>(emptyMap())
    val discoveredBlePeers: StateFlow<Map<String, DiscoveredBleNode>> = _discoveredBlePeers.asStateFlow()

    @SuppressLint("MissingPermission")
    fun startAdvertising() {
        if (adapter?.isEnabled != true) return
        advertiser = adapter.bluetoothLeAdvertiser ?: return
        val settings = AdvertiseSettings.Builder().setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_BALANCED).build()
        val idBytes = identityManager.cachedInstallationId.take(12).toByteArray(StandardCharsets.UTF_8)
        val data = AdvertiseData.Builder().addServiceUuid(ParcelUuid(RADIUS_UUID)).addServiceData(ParcelUuid(RADIUS_UUID), idBytes).build()
        advertiser?.startAdvertising(settings, data, object : AdvertiseCallback() {})
    }

    @SuppressLint("MissingPermission")
    fun startScanning() {
        if (adapter?.isEnabled != true) return
        scanner = adapter.bluetoothLeScanner ?: return
        val filters = listOf(ScanFilter.Builder().setServiceUuid(ParcelUuid(RADIUS_UUID)).build())
        val settings = ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build()
        scanner?.startScan(filters, settings, object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult?) {
                val data = result?.scanRecord?.getServiceData(ParcelUuid(RADIUS_UUID)) ?: return
                val id = String(data, StandardCharsets.UTF_8)
                val node = DiscoveredBleNode(id, "Peer", result.device.address, result.rssi, System.currentTimeMillis())
                _discoveredBlePeers.value = _discoveredBlePeers.value + (id to node)
            }
        })
    }

    data class DiscoveredBleNode(val installationId: String, val displayName: String, val address: String, val rssi: Int, val timestamp: Long)

    companion object {
        val RADIUS_UUID: UUID = UUID.fromString("06e5e001-6b21-4d92-b430-8d54608c0001")
    }
}