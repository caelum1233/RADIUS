package com.sixthsense.radius.identity

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.security.SecureRandom

private val Context.dataStore by preferencesDataStore(name = "radius_identity_prefs")

class IdentityManager(private val context: Context) {
    private val secureRandom = SecureRandom()

    val displayNameFlow: Flow<String?> = context.dataStore.data.map { it[KEY_DISPLAY_NAME] }
    val installationIdFlow: Flow<String?> = context.dataStore.data.map { it[KEY_INSTALLATION_ID] }
    val publicKeyFlow: Flow<String?> = context.dataStore.data.map { it[KEY_PUBLIC_KEY] }

    var cachedInstallationId: String = ""
        private set
    var cachedDisplayName: String = ""
        private set

    suspend fun initialize() {
        val prefs = context.dataStore.data.first()
        var id = prefs[KEY_INSTALLATION_ID]
        if (id.isNullOrBlank()) {
            val randomBytes = ByteArray(16).also { secureRandom.nextBytes(it) }
            id = "RAD-" + randomBytes.joinToString("") { "%02x".format(it) }
            val pubBytes = ByteArray(32).also { secureRandom.nextBytes(it) }
            context.dataStore.edit { editPrefs ->
                editPrefs[KEY_INSTALLATION_ID] = id
                editPrefs[KEY_PUBLIC_KEY] = pubBytes.joinToString("") { "%02x".format(it) }
            }
        }
        cachedInstallationId = id
        cachedDisplayName = prefs[KEY_DISPLAY_NAME] ?: ""
    }

    suspend fun registerUser(displayName: String) {
        val trimmed = displayName.trim().take(32)
        context.dataStore.edit { it[KEY_DISPLAY_NAME] = trimmed }
        cachedDisplayName = trimmed
    }

    companion object {
        private val KEY_INSTALLATION_ID = stringPreferencesKey("rad_installation_id")
        private val KEY_DISPLAY_NAME = stringPreferencesKey("rad_display_name")
        private val KEY_PUBLIC_KEY = stringPreferencesKey("rad_x25519_pub")
    }
}