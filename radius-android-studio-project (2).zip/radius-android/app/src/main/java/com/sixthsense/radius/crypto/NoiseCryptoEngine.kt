package com.sixthsense.radius.crypto

import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

class NoiseCryptoEngine {
    private val secureRandom = SecureRandom()
    private var outgoingSequence = 0L
    private val incomingPeerSequences = mutableMapOf<String, Long>()

    fun encryptPayload(plain: ByteArray, sharedSecret: ByteArray, senderId: String, recipientId: String): EncryptedData {
        val iv = ByteArray(12).also { secureRandom.nextBytes(it) }
        outgoingSequence++
        val seqBytes = ByteArray(8) { i -> ((outgoingSequence shr (i * 8)) and 0xFF).toByte() }
        val aad = (senderId + ":" + recipientId).toByteArray(Charsets.UTF_8) + seqBytes

        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(sharedSecret, 0, 32.coerceAtMost(sharedSecret.size), "AES"), GCMParameterSpec(128, iv))
        cipher.updateAAD(aad)
        return EncryptedData(cipher.doFinal(plain), iv, outgoingSequence)
    }

    fun decryptPayload(cipherBytes: ByteArray, iv: ByteArray, seq: Long, senderId: String, recipientId: String, sharedSecret: ByteArray): ByteArray? {
        return try {
            val lastSeen = incomingPeerSequences[senderId] ?: 0L
            if (seq <= lastSeen && lastSeen != 0L) return null // Replay detected
            val seqBytes = ByteArray(8) { i -> ((seq shr (i * 8)) and 0xFF).toByte() }
            val aad = (senderId + ":" + recipientId).toByteArray(Charsets.UTF_8) + seqBytes

            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(sharedSecret, 0, 32.coerceAtMost(sharedSecret.size), "AES"), GCMParameterSpec(128, iv))
            cipher.updateAAD(aad)
            val plain = cipher.doFinal(cipherBytes)
            incomingPeerSequences[senderId] = seq
            plain
        } catch (e: Exception) { null }
    }

    data class EncryptedData(val cipherText: ByteArray, val iv: ByteArray, val sequence: Long)

    companion object {
        fun deriveChannelKey(channel: String): ByteArray {
            return java.security.MessageDigest.getInstance("SHA-256")
                .digest(("RADIUS_OFFLINE_SALT_" + channel).toByteArray(Charsets.UTF_8))
        }
    }
}